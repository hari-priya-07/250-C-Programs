#include <stdio.h>
int main() {
    char str[101];
    scanf(" %[^
]", str);
    for(int i = 0; i < 4; i++) {
        printf("%s\n", str);
    }
    return 0;
}
