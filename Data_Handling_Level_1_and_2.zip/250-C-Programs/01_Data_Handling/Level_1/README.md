# Data Handling – Level 1

This folder contains beginner-level C programs for practicing basic input/output operations and arithmetic.

### Programs:
1. Accept and print a character
2. Accept and print an integer
3. Accept and print a float (3 decimal places)
4. Accept and print a string
5. Print a string 4 times in new lines
6. Accept two integers and print their sum
7. Accept two integers and print their product
8. Convert Celsius to Fahrenheit (2 decimal places)
9. Calculate area of a circle from radius
10. Print ASCII value of a character
