#include <stdio.h>
#define PI 3.1416
int main() {
    float radius;
    scanf("%f", &radius);
    float area = PI * radius * radius;
    printf("%.3f", area);
    return 0;
}
