#include <stdio.h>
int main() {
    char str[101];
    scanf(" %[^
]", str);
    printf("%s", str);
    return 0;
}
