#include <stdio.h>
int main() {
    float num;
    scanf("%f", &num);
    printf("%.3f", num);
    return 0;
}
