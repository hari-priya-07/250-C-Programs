#include <stdio.h>
#include <math.h>
int main() {
    float num;
    scanf("%f", &num);
    printf("%d", (int)round(num));
    return 0;
}
