#include <stdio.h>
int main() {
    float num;
    int precision;
    scanf("%f %d", &num, &precision);
    printf("%.*f", precision, num);
    return 0;
}
