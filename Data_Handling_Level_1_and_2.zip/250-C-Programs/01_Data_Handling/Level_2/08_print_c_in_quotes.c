#include <stdio.h>
int main() {
    printf("Welcome to the World of \"C\" Programming");
    return 0;
}
