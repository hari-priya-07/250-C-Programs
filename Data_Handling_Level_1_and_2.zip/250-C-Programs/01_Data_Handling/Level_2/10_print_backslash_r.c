#include <stdio.h>
int main() {
    printf("\\r");
    return 0;
}
