#include <stdio.h>
int main() {
    float num;
    scanf("%f", &num);
    printf("%15.2f", num);
    return 0;
}
