#include <stdio.h>
int main() {
    int num;
    scanf("%i", &num);
    printf("%d", num);
    return 0;
}
