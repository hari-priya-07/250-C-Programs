#include <stdio.h>
int main() {
    int num;
    scanf("%d", &num);
    printf("%c", num);
    return 0;
}
